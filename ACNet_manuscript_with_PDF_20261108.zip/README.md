# ACNet

论文协作仓库：**ACNet: Paired Structural Recovery and Patient-Balanced Risk Calibration for Semi-Supervised Medical Image Segmentation**。

- **[阅读当前论文 PDF](paper/main.pdf)**
- **[查看或修改 LaTeX 源文件](paper/main.tex)**
- **[查看论文配图](paper/images/)**

## 文件说明

`paper/` 包含当前手稿、25 页 PDF、正文引用的 14 幅图和所需的本地 LaTeX 类／样式文件。PDF 是当前手稿的阅读版本；修改时请以 `paper/main.tex` 为源文件，并保留图件的相对路径。

本次只上传论文材料，未包含训练代码、数据集、模型权重、训练输出或内部运行日志。论文仍在修订，未填写的实验项目以正文说明为准。

## 编译

从 `paper` 文件夹使用 XeLaTeX 编译两次：

```sh
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
```

当前源文件使用 `KaiTi`（楷体）和 `Times New Roman` 字体，编译环境需具备这两种字体。

## 共享与修改

可以直接分享本仓库链接供阅读。修改建议可通过 Issues 提交；如需提交改稿，可 Fork 后发起 Pull Request，或由仓库所有者另行添加协作者。
