# 论文源文件

- `main.pdf`：当前 25 页论文，供直接阅读。
- `main.tex`：LaTeX 主文件。
- `images/`：正文引用图件，保留现有相对路径。
- `cas-sc.cls`、`cas-common.sty`、`cas-model2-names.bst`：本地 Elsevier CAS 支持文件。

使用 XeLaTeX 编译两次。当前字体为 KaiTi 和 Times New Roman。
